package com.bestr.bradl.bestr;

import android.app.FragmentManager;
import android.app.FragmentTransaction;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;



public class MainActivity extends AppCompatActivity implements View.OnClickListener{


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

            getSupportActionBar().setDisplayShowHomeEnabled(true);
            getSupportActionBar().setLogo(R.mipmap.ic_launcher);
            getSupportActionBar().setDisplayUseLogoEnabled(true);



        setContentView(R.layout.activity_main);;
            }

    public void launchCreateGoalActivity(View view) {
        Intent intent = new Intent(this, CreateGoalActivity.class);
        startActivity(intent);


    }

    public void WorldStandingsOpen(View view){
        Intent intent = new Intent(this, WorldStandingsActivity.class);
        startActivity(intent);
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.mainmenu, menu);
        return true;
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch(item.getItemId()) {
            case R.id.contact:
                Intent intent = new Intent(this, ContactUsActivity.class);
                this.startActivity(intent);
                break;
            case R.id.about:
                Intent intent2 = new Intent(this, AboutActivity.class);
                this.startActivity(intent2);
                break;
            default:
                return super.onOptionsItemSelected(item);
        }

        return true;
    }




    public void ToggleScore(View view) {
        FragmentManager fm = getFragmentManager();
        AchievementsFragment otherfr = new AchievementsFragment();

        PublicGoalsFragment otherfr2x = new PublicGoalsFragment();
        FragmentTransaction ft = fm.beginTransaction();
        ft.add(R.id.bottomfragment, otherfr, "achievementsfragment");
        AchievementsFragment test = (AchievementsFragment) getFragmentManager().findFragmentByTag("achievementsfragment");

        if (test != null && test.isVisible()) {

            //find the bottom fragment.
            Button ShowHideScore = (Button) findViewById(R.id.viewScore);
            ShowHideScore.setText("Hide Unofficial Bestr. Score");
            ft.replace(R.id.bottomfragment, otherfr2x);
        } else {

            //find the bottom fragment.
            Button ShowHideScore = (Button) findViewById(R.id.viewScore);
            ShowHideScore.setText("Show Unofficial Bestr. Score");
            ft.replace(R.id.bottomfragment, otherfr);
        }
        ft.addToBackStack(null);
        ft.setTransition(FragmentTransaction.TRANSIT_FRAGMENT_FADE).commit();//Whatever

    }

    @Override
    public void onClick(View v) {
        //find the fragment manager that knows about all fragements.

    }


}