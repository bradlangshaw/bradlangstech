package com.bestr.bradl.bestr;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.maps.CameraUpdate;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.CameraPosition;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;

/**
 * Created by bradl on 1/12/2018.
 */

public class ContactUsActivity extends AppCompatActivity implements OnMapReadyCallback, View.OnClickListener {

    Context context;
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.contactus_layout);

        Button startBtn = (Button) findViewById(R.id.sendbtn);
        startBtn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                sendEmail();
            }
        });
        Button callBtn = (Button) findViewById(R.id.Callbtn);
        callBtn.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                dialContactPhone("17053213945");

            }
            private void dialContactPhone(final String phoneNumber) {
                startActivity(new Intent(Intent.ACTION_DIAL, Uri.fromParts("tel", phoneNumber, null)));
            }
        });
        SupportMapFragment mapFragment = ((SupportMapFragment) getSupportFragmentManager().findFragmentById(R.id.map));

        mapFragment.getMapAsync(this);


    }

    protected void sendEmail() {
        Log.i("Send email", "");
        String[] TO = {"brad.langshaw@live.ca"};
        Intent emailIntent = new Intent(Intent.ACTION_SEND);
        EditText mEdit = (EditText) findViewById(R.id.message);

        emailIntent.setData(Uri.parse("mailto:"));
        emailIntent.setType("text/plain");
        emailIntent.putExtra(Intent.EXTRA_EMAIL, TO);
        emailIntent.putExtra(Intent.EXTRA_SUBJECT, "");
        emailIntent.putExtra(Intent.EXTRA_TEXT, mEdit.getText().toString());

        try {
            startActivity(Intent.createChooser(emailIntent, "Send mail..."));
            finish();
            Log.i("Finished sending email", "");
        } catch (android.content.ActivityNotFoundException ex) {
            Toast.makeText(ContactUsActivity.this, "There is no email client installed.", Toast.LENGTH_SHORT).show();
        }
    }


    public void onMapReady(GoogleMap googleMap) {
        LatLng toronto = new LatLng(43.6705273, -79.3860069);


        googleMap.addMarker(new MarkerOptions().position(toronto)
                .title("Marker at Toronto"));
        CameraPosition cameraPosition = new CameraPosition.Builder().target(toronto).zoom(18.0f).build();
        CameraUpdate cameraUpdate = CameraUpdateFactory.newCameraPosition(cameraPosition);

        googleMap.moveCamera(cameraUpdate);
    }

    public void MakeCall(View view) {

    }

    @Override
    public void onClick(View v) {

    }
}
