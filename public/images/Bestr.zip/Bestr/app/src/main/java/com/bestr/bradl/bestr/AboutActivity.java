package com.bestr.bradl.bestr;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

/**
 * Created by bradl on 1/12/2018.
 */

public class AboutActivity extends AppCompatActivity{
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.about_layout);

    }

    }
