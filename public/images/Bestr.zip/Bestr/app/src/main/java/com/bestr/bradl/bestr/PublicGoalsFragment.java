package com.bestr.bradl.bestr;

import android.app.Fragment;
import android.app.FragmentManager;
import android.app.FragmentTransaction;
import android.os.Bundle;
import android.view.GestureDetector;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.content.Context;
import android.widget.RelativeLayout;

/**
 * Created by bradl on 1/6/2018.
 **/

public class PublicGoalsFragment extends Fragment  {

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View current = inflater.inflate(R.layout.publicgoalsfragment, container, false);

        return current;
    }


}



