package com.bestr.bradl.bestr;

import android.app.Fragment;
import android.app.FragmentManager;
import android.content.Context;
import android.support.v13.app.FragmentPagerAdapter;
/**
 * Created by bradl
 **/

public class CustomPagerAdapter extends FragmentPagerAdapter {
    Context context;
    private static int NUM_ITEMS = 2;

    private String[] titles= new String[]{"Choose Goal Type", "Create New Goal"};

    public CustomPagerAdapter(FragmentManager fm) {
        super(fm);
    }

    //How many pages are in your fragment?
    @Override
    public int getCount() {
        return NUM_ITEMS;
    }

    //getting the related title to the position of the tab (Tab is an array)
    @Override
    public String getPageTitle(int position) {
        return titles[position];
    }




    //describe your fragment?
    @Override
    public Fragment getItem(int position) {

        //send in the position and create a new tab fragment.

        switch (position){
            case 0:
                return ChooseGoalType.newInstance(position, titles[position]); //Tab1.newInstance(position, "Tab 1");
            case 1:
                return NewGoalFragment.newInstance(position, titles[position]); // Tab2.newInstance(position, "Tab 2");
            default:
                return NewGoalFragment.newInstance(position, titles[position]);


        }

    }
}
