package com.bestr.bradl.bestr;

import android.app.Fragment;
import android.app.FragmentManager;
import android.app.FragmentTransaction;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.res.Configuration;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.app.Activity;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Calendar;


/**
 * Created by bradl on 1/6/2018.
 */

public class AchievementsFragment extends Fragment {
    int mCurCheckPosition = 0;
    @Override
    public void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        Toast.makeText(getActivity(), "onSaveInstanceState",
                Toast.LENGTH_LONG).show();

        outState.putInt("curChoice", mCurCheckPosition);
    }
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.achievementsfragment, container, false);




        Button updateStatsBtn = (Button) view.findViewById(R.id.updatestatsbtn);
        updateStatsBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                switch (v.getId()) {

                    case R.id.updatestatsbtn:
                        Intent intent = new Intent(getActivity(), CreateGoalActivity.class);
                        startActivity(intent);
                        break;


                }
            }
        });

        return view;


    }


}