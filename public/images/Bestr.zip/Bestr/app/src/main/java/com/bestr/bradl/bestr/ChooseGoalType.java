package com.bestr.bradl.bestr;

/**
 * Created by bradl on 1/12/2018.
 **/
import android.app.Fragment;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;


public class ChooseGoalType extends Fragment {
    //constant to keep track of what you are sending
    private String title;
    private int page;


    static ChooseGoalType newInstance(int position, String title) {
        ChooseGoalType frag=new ChooseGoalType();
        Bundle args=new Bundle();

        //take the position and send it to create the fragment.
        args.putInt("tab", position);
        args.putString("title", title);

        frag.setArguments(args);

        return(frag);
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        page = getArguments().getInt("tab", 0);
        title = getArguments().getString("title");
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View result=inflater.inflate(R.layout.choosegoal_layout, container, false);

        //int position=getArguments().getInt("tab", -1);

        return(result);
    }
}