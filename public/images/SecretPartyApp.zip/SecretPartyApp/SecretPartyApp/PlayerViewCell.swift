//
//  PlayerViewCell.swift
//  SecretPartyApp
//
//  Created by Brad Langshaw on 2018-03-07.
//  Copyright © 2018 Brad Langshaw. All rights reserved.
//

import UIKit

class PlayerViewCell: UITableViewCell {
    
   @IBOutlet weak var label: UILabel!
    @IBOutlet weak var label1: UILabel!
 
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
