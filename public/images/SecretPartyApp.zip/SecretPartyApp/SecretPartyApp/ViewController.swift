//
//  ViewController.swift
//  SecretPartyApp
//
//  Created by Brad Langshaw on 2018-03-01.
//  Copyright © 2018 Brad Langshaw. All rights reserved.
//

import UIKit			

class ViewController: UIViewController, UICollectionViewDataSource, UICollectionViewDelegate, UIImagePickerControllerDelegate,
    UINavigationControllerDelegate
{ 
    
    let reuseIdentifier = "collectionCell" // also enter this string as the cell identifier in the storyboard
    private var tasks = ["Build a tower out of some anatimate object ","Eat something odd from the fridge","Kiss someone you havent met","Make the host a drink thats too strong","Hang 4 sheets of toilet paper from something","Tell a fake story about yourself. Make it seem real","Get 4 other party guests to make the same obscure noise as you","Say something completely out of context of a conversation","Wear something on your head, thats not meant to be worn on your head","Play a drinking game","Ask when the party starts once an hour"]
    var resultSet = Set<String>()
    
   
    
    
  
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        
        while resultSet.count < 9 {
            let randomIndex = Int(arc4random_uniform(UInt32(tasks.count)))
            resultSet.insert(tasks[randomIndex])
        }
        return resultSet.count
        
    }
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
    
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: reuseIdentifier, for: indexPath as IndexPath) as! CollectionViewCell
 
        let resultArray1 = Array(resultSet)
   
        cell.TaskLabel.text = resultArray1[indexPath.item]
        cell.backgroundColor = UIColor.white // make cell more visible in our example project
        
        return cell
    }
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        // handle tap events
        let resultArray1 = Array(resultSet)
        print("You selected cell #\(resultArray1[indexPath.item])!")
        
    }


    @IBOutlet weak var NavItem: UINavigationItem!
   
    @IBOutlet weak var shootPhoto: UIButton!
    
    @IBOutlet weak var photoFromLibrary: UIButton!
    
    @IBOutlet weak var PlayersBtn: UIButton!
    override func viewDidLoad() {
        
        let alert = UIAlertController(title: "Rules", message: "This game is about messing with your friends to see their reactions, and to challenge yourself to do something out of your comfort-zone. On your way to a gathering? have atleast 4 friends(3 players, 1 moderater) with you, and get them all to install this app. Join eachothers group and you will be given 9 tasks to complete before the night is over, if any of the guest figure out you are playing the game you lose and the person with the most completed tasks wins.", preferredStyle: UIAlertControllerStyle.alert)	
        self.present(alert, animated: true, completion: nil)
        // Do any additional setup after loading the view, typically from a
        alert.addAction(UIAlertAction(title: "Ok", style: .default, handler: { action in
        switch action.style{
        case .default:
            print("default")
            
        case .cancel:
            print("cancel")
            
        case .destructive:
            print("destructive")
             super.viewDidLoad()
        }}))
           picker.delegate = self
    

    }

    @IBAction func PlayersBtn(_ sender: Any) {

        show((self.storyboard?.instantiateViewController(withIdentifier: "playersController"))!, sender: (Any).self)

    }
    
    let picker = UIImagePickerController()
    
    
    @IBAction func photoFromLibrary(_ sender: UIButton) {
    picker.allowsEditing = false
    picker.sourceType = .photoLibrary
    picker.mediaTypes = UIImagePickerController.availableMediaTypes(for: .photoLibrary)!
    picker.modalPresentationStyle = .popover
    present(picker, animated: true, completion: nil)
    picker.popoverPresentationController?.sourceView = sender
    }
    
    @IBAction func shootPhoto(_ sender: UIButton) {
    if UIImagePickerController.isSourceTypeAvailable(.camera) {
        picker.allowsEditing = false
        picker.sourceType = UIImagePickerControllerSourceType.camera
        picker.cameraCaptureMode = .photo
        picker.modalPresentationStyle = .fullScreen
        present(picker,animated: true,completion: nil)
        } else {
        noCamera()
        }
        }
    
    
    func noCamera(){
    let alertVC = UIAlertController(
            title: "No Camera",
            message: "Sorry, this device has no camera",
            preferredStyle: .alert)
    let okAction = UIAlertAction(
            title: "OK",
            style:.default,
            handler: nil)
            alertVC.addAction(okAction)
            present(
            alertVC,
            animated: true,
            completion: nil)
            }
    
    @IBOutlet weak var myImageView: UIImageView!
    
    //MARK: - Delegates
    private func imagePickerController(_ picker: UIImagePickerController,
    didFinishPickingMediaWithInfo info: [String : AnyObject])
    {
    var  chosenImage = UIImage()
    chosenImage = info[UIImagePickerControllerOriginalImage] as! UIImage //2
    myImageView.contentMode = .scaleAspectFit //3
    myImageView.image = chosenImage //4
    dismiss(animated:true, completion: nil) //5
    }
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
    dismiss(animated: true, completion: nil)
    }




    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
  

    
}


