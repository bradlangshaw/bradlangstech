//
//  CollectionViewCell.swift
//  SecretPartyApp
//
//  Created by Brad Langshaw on 2018-03-07.
//  Copyright © 2018 Brad Langshaw. All rights reserved.
//

import UIKit

class CollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var TaskLabel: UILabel!
    
}
