//
//  InfoViewController.swift
//  SecretPartyApp
//
//  Created by Brad Langshaw on 2018-03-09.
//  Copyright © 2018 Brad Langshaw. All rights reserved.
//
import MessageUI
 import UIKit
    fileprivate func < <T : Comparable>(lhs: T?, rhs: T?) -> Bool {
        switch (lhs, rhs) {
        case let (l?, r?):
            return l < r
        case (nil, _?):
            return true
        default:
            return false
        }
    }
    
    fileprivate func > <T : Comparable>(lhs: T?, rhs: T?) -> Bool {
        switch (lhs, rhs) {
        case let (l?, r?):
            return l > r
        default:
            return rhs < lhs
        }
    }
    
    
class InfoViewController: UIViewController,  MFMailComposeViewControllerDelegate {

    @IBOutlet weak var CallUs: UIButton!
    @IBOutlet weak var EmailUsSuggestions: UIButton!
    
        var percentDrivenInteractiveTransition: UIPercentDrivenInteractiveTransition!
        var panGestureRecognizer: UIPanGestureRecognizer!
        
        override func viewDidLoad() {
            super.viewDidLoad()
    
    
            addGesture()
        }
        
    @IBAction func CallHandler(_ sender: UIButton) {
        if let url = URL(string: "tel://\(705-321-3945)"), UIApplication.shared.canOpenURL(url) {
        if #available(iOS 10, *) {
            UIApplication.shared.open(url)
        } else {
            UIApplication.shared.openURL(url)
        }
        }    }
    @IBAction func EmailHandler(_ sender: UIButton) {
        if !MFMailComposeViewController.canSendMail() {
            print("Mail services are not available")
            return
        }
        sendEmail()
        
    }
    func addGesture() {
            
            guard navigationController?.viewControllers.count > 1 else {
                return
            }
            
            panGestureRecognizer = UIPanGestureRecognizer(target: self, action: #selector(InfoViewController.handlePanGesture(_:)))
            self.view.addGestureRecognizer(panGestureRecognizer)
        }
        
        @objc func handlePanGesture(_ panGesture: UIPanGestureRecognizer) {
            
            let percent = max(panGesture.translation(in: view).x, 0) / view.frame.width
            
            switch panGesture.state {
                
            case .began:
                navigationController?.delegate = (self as UINavigationControllerDelegate)
                _ = navigationController?.popViewController(animated: true)
                
            case .changed:
                if let percentDrivenInteractiveTransition = percentDrivenInteractiveTransition {
                    percentDrivenInteractiveTransition.update(percent)
                }
                
            case .ended:
                let velocity = panGesture.velocity(in: view).x
                
                // Continue if drag more than 50% of screen width or velocity is higher than 1000
                if percent > 0.5 || velocity > 1000 {
                    percentDrivenInteractiveTransition.finish()
                } else {
                    percentDrivenInteractiveTransition.cancel()
                }
                
            case .cancelled, .failed:
                percentDrivenInteractiveTransition.cancel()
                
            default:
                break
            }
        }
        
    
   
    
    
    
    
    func sendEmail() {
    let composeVC = MFMailComposeViewController()
    composeVC.mailComposeDelegate = self
    // Configure the fields of the interface.
    composeVC.setToRecipients(["address@example.com"])
    composeVC.setSubject("Hello!")
    composeVC.setMessageBody("Hello this is my message body!", isHTML: false)
    // Present the view controller modally.
    self.present(composeVC, animated: true, completion: nil)
    }
    
    private func mailComposeController(controller: MFMailComposeViewController,
    didFinishWithResult result: MFMailComposeResult, error: NSError?) {
    // Check the result or perform other tasks.
    // Dismiss the mail compose view controller.
    controller.dismiss(animated: true, completion: nil)
    }
    
    override func didReceiveMemoryWarning() {
    super.didReceiveMemoryWarning()
    // Dispose of any resources that can be recreated.
    }
    }

    
    
    extension InfoViewController: UINavigationControllerDelegate {
        
        func navigationController(_ navigationController: UINavigationController, animationControllerFor operation: UINavigationControllerOperation, from fromVC: UIViewController, to toVC: UIViewController) -> UIViewControllerAnimatedTransitioning? {
            
            return SlideAnimatedTransitioning()
        }
        
        func navigationController(_ navigationController: UINavigationController, interactionControllerFor animationController: UIViewControllerAnimatedTransitioning) -> UIViewControllerInteractiveTransitioning? {
            
            navigationController.delegate = nil
            
            if panGestureRecognizer.state == .began {
                percentDrivenInteractiveTransition = UIPercentDrivenInteractiveTransition()
                percentDrivenInteractiveTransition.completionCurve = .easeOut
            } else {
                percentDrivenInteractiveTransition = nil
            }
            
            return percentDrivenInteractiveTransition
        }
}

