	//
//  playersController.swift
//  SecretPartyApp
//
//  Created by Brad Langshaw on 2018-03-05.
//  Copyright © 2018 Brad Langshaw. All rights reserved.
//

import UIKit
    fileprivate func < <T : Comparable>(lhs: T?, rhs: T?) -> Bool {
        switch (lhs, rhs) {
        case let (l?, r?):
            return l < r
        case (nil, _?):
            return true
        default:
            return false
        }
    }
    
    fileprivate func > <T : Comparable>(lhs: T?, rhs: T?) -> Bool {
        switch (lhs, rhs) {
        case let (l?, r?):
            return l > r
        default:
            return rhs < lhs
        }
    }
    
class playersController: UIViewController, UITableViewDataSource {

        
        @IBOutlet weak var PlayersDesc: PlayerViewCell!
        
        @IBOutlet weak var tableView: UITableView!
       
        override  func viewDidLoad() {
        super.viewDidLoad()
    tableView.dataSource = self
             addGesture()
//        tableView.register(UINib(nibName: "PlayerViewCell", bundle: nil), forCellReuseIdentifier: "playerCell")
        // Uncomment the following line to preserve selection between presentations
        // self.clearsSelectionOnViewWillAppear = false

        // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
        // self.navigationItem.rightBarButtonItem = self.editButtonItem
    }
        private var players = ["Taylor","Brad","Ross","Lynda","Brian","Martha","Larry","Mike","Felica","Mary","Stan"]
        
    override  func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    // MARK: - Table view data source

    
//    override func numberOfSections(in tableView: UITableView) -> Int {
//        return 1
       //  }
        func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        return 2
    }
        func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
      
              return players.count // just for testing, add here yourrealdata.count
           
        }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "playerCell", for: indexPath) as! PlayerViewCell
      
            let text = players[indexPath.row]
            
        cell.label.text = text // return test rows as set in numberOfRowsInSection
      

      
        
        return cell
    }

    
        var percentDrivenInteractiveTransition: UIPercentDrivenInteractiveTransition!
        var panGestureRecognizer: UIPanGestureRecognizer!

        
        func addGesture() {
            
            guard navigationController?.viewControllers.count > 1 else {
                return
            }
            
            panGestureRecognizer = UIPanGestureRecognizer(target: self, action: #selector(playersController.handlePanGesture(_:)))
            self.view.addGestureRecognizer(panGestureRecognizer)
        }
        
        @objc func handlePanGesture(_ panGesture: UIPanGestureRecognizer) {
            
            let percent = max(panGesture.translation(in: view).x, 0) / view.frame.width
            
            switch panGesture.state {
                
            case .began:
                navigationController?.delegate = (self as UINavigationControllerDelegate)
                _ = navigationController?.popViewController(animated: true)
                
            case .changed:
                if let percentDrivenInteractiveTransition = percentDrivenInteractiveTransition {
                    percentDrivenInteractiveTransition.update(percent)
                }
                
            case .ended:
                let velocity = panGesture.velocity(in: view).x
                
                // Continue if drag more than 50% of screen width or velocity is higher than 1000
                if percent > 0.5 || velocity > 1000 {
                    percentDrivenInteractiveTransition.finish()
                } else {
                    percentDrivenInteractiveTransition.cancel()
                }
                
            case .cancelled, .failed:
                percentDrivenInteractiveTransition.cancel()
                
            default:
                break
            }
        }
        


}
    
    
    extension playersController: UINavigationControllerDelegate {
        
        func navigationController(_ navigationController: UINavigationController, animationControllerFor operation: UINavigationControllerOperation, from fromVC: UIViewController, to toVC: UIViewController) -> UIViewControllerAnimatedTransitioning? {
            
            return SlideAnimatedTransitioning()
        }
        
        func navigationController(_ navigationController: UINavigationController, interactionControllerFor animationController: UIViewControllerAnimatedTransitioning) -> UIViewControllerInteractiveTransitioning? {
            
            navigationController.delegate = nil
            
            if panGestureRecognizer.state == .began {
                percentDrivenInteractiveTransition = UIPercentDrivenInteractiveTransition()
                percentDrivenInteractiveTransition.completionCurve = .easeOut
            } else {
                percentDrivenInteractiveTransition = nil
            }
            
            return percentDrivenInteractiveTransition
        }
    }
